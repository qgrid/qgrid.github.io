import {Component, OnInit} from '@angular/core'
import {Http} from '@angular/http';

import {DataService, Human} from './data.service';
import {GridModel, Grid} from 'ng2-qgrid';


@Component({
  selector: 'my-app',
  templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {
   public gridModel: GridModel;

   constructor(qgrid: Grid, private dataService: DataService) {
      this.gridModel = qgrid.model();
   }

   ngOnInit(): void {
    this.dataService
      .getPeople(100)
      .subscribe(people => {
        this.gridModel
          .data({
            rows: people
          });
      });
  }
}
